from collections.abc import Callable
from pathlib import Path
from uuid import uuid4

from app.models.audit_run import AuditFailure, AuditRun, utc_now
from app.models.policy import PolicySet
from app.services.auditor import (
    DEFAULT_INFERENCE_MODEL,
    PROMPT_VERSION,
    audit_policy,
)
from app.services.embedder import EMBEDDING_MODEL
from app.services.retriever import retrieve_for_policy

ProgressCallback = Callable[[int, int, str], None]


def run_complete_audit(
    collection,
    policy_set: PolicySet,
    document_id: str,
    source_filename: str,
    prompt_path: str | Path,
    *,
    top_k: int = 3,
    model: str = DEFAULT_INFERENCE_MODEL,
    progress_callback: ProgressCallback | None = None,
) -> AuditRun:
    started_at = utc_now()
    findings = []
    failures = []
    total = len(policy_set.policies)

    for index, policy in enumerate(policy_set.policies, start=1):
        if progress_callback is not None:
            progress_callback(index - 1, total, policy.policy_id)

        try:
            evidence = retrieve_for_policy(
                collection,
                policy,
                document_id=document_id,
                top_k=top_k,
            )
            finding = audit_policy(
                policy,
                evidence,
                prompt_path,
                model=model,
            )
            findings.append(finding)
        except Exception as exc:
            failures.append(
                AuditFailure(
                    policy_id=policy.policy_id,
                    policy_title=policy.title,
                    error=f"{type(exc).__name__}: {exc}",
                )
            )

        if progress_callback is not None:
            progress_callback(index, total, policy.policy_id)

    return AuditRun(
        audit_run_id=f"AUD-{uuid4().hex[:12].upper()}",
        document_id=document_id,
        source_filename=source_filename,
        started_at=started_at,
        completed_at=utc_now(),
        policy_set_id=policy_set.policy_set_id,
        embedding_model=EMBEDDING_MODEL,
        inference_model=model,
        prompt_version=PROMPT_VERSION,
        total_policies=total,
        findings=findings,
        failures=failures,
    )
