from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT))

import streamlit as st
import pandas as pd

from app.data.mock_findings import MOCK_FINDINGS
from app.data.sample_policies import SAMPLE_POLICIES

st.set_page_config(
    page_title="Vendor Compliance Auditor",
    layout="wide"
)

# Sidebar
st.sidebar.title("Demo Information")

st.sidebar.info(
    """
    Review Version

    Uses synthetic policies and deterministic findings.

    Real extraction, redaction, retrieval and LLM
    analysis will be connected in later phases.
    """
)

st.sidebar.subheader("Synthetic Dataset")

st.sidebar.write(
    """
    The bundled four-page contract contains:

    - Synthetic PII
    - A compliant encryption clause
    - A non-compliant notification clause
    - Ambiguous retention wording
    - Deliberately missing audit rights
    """
)

# Main Page
st.title("RAG-Powered Vendor Compliance Auditor")

st.markdown(
    """
    **Demonstration Version**

    Uses synthetic policies and mock findings.
    """
)

# Upload Section
uploaded_file = st.file_uploader(
    "Upload Contract PDF",
    type=["pdf"]
)

if uploaded_file:
    st.success(f"Selected file: {uploaded_file.name}")

    st.caption(
        "Session 2 uses deterministic findings. "
        "PDF extraction will be connected in Session 3."
    )

st.divider()

# Main Layout
col1, col2 = st.columns([1, 2])

with col1:
    st.subheader("Sample Policies")

    for policy in SAMPLE_POLICIES:
        with st.expander(policy["title"]):
            st.write(policy["requirement"])

with col2:
    st.subheader("Audit Findings")

    if "audit_completed" not in st.session_state:
        st.session_state.audit_completed = False

    if st.button("Run Mock Audit"):
        st.session_state.audit_completed = True

    if st.session_state.audit_completed:

        df = pd.DataFrame(MOCK_FINDINGS)

        total = len(df)
        compliant = len(df[df["status"] == "COMPLIANT"])
        issues = len(df[df["status"].isin(["NON_COMPLIANT", "MISSING"])])
        review = len(df[df["status"] == "AMBIGUOUS"])

        m1, m2, m3, m4 = st.columns(4)

        m1.metric("Policies Checked", total)
        m2.metric("Compliant", compliant)
        m3.metric("Issues", issues)
        m4.metric("Review Needed", review)

        st.divider()

        st.subheader("Audit Findings Table")

        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True
        )

        st.divider()

        st.subheader("Finding Summary")

        for finding in MOCK_FINDINGS:

            status = finding["status"]

            if status == "COMPLIANT":
                st.success(f"{finding['policy']} : {status}")

            elif status == "NON_COMPLIANT":
                st.error(f"{finding['policy']} : {status}")

            elif status == "MISSING":
                st.warning(f"{finding['policy']} : {status}")

            else:
                st.info(f"{finding['policy']} : {status}")

        st.divider()

        st.subheader("Evidence Details")

        selected_policy = st.selectbox(
            "Select Policy",
            [item["policy"] for item in MOCK_FINDINGS]
        )

        selected_finding = next(
            item
            for item in MOCK_FINDINGS
            if item["policy"] == selected_policy
        )

        st.write("### Evidence")
        st.code(selected_finding["evidence"])

        st.write("### Explanation")
        st.write(selected_finding["explanation"])

        st.write("### Recommendation")
        st.write(selected_finding["recommendation"])

        page = selected_finding["page"]

        page_display = (
            page
            if page is not None
            else "No evidence page"
        )

        st.write(f"**Contract Page:** {page_display}")

        st.success("Audit completed successfully")
