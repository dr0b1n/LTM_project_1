from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
import streamlit as st

from app.data.mock_findings import MOCK_FINDINGS
from app.data.sample_policies import SAMPLE_POLICIES
from app.services.document_extractor import (
    DocumentExtractionError,
    extract_pdf,
)
from app.services.chunker import chunk_document
from app.services.pii_redactor import redact_document

st.set_page_config(page_title="Vendor Compliance Auditor", layout="wide")

if "audit_completed" not in st.session_state:
    st.session_state.audit_completed = False
if "extracted_document" not in st.session_state:
    st.session_state.extracted_document = None
if "uploaded_file_key" not in st.session_state:
    st.session_state.uploaded_file_key = None
if "redaction_summary" not in st.session_state:
    st.session_state.redaction_summary = None
if "contract_chunks" not in st.session_state:
    st.session_state.contract_chunks = []

st.sidebar.title("Demo Information")
st.sidebar.info(
    "This review version uses a synthetic contract and deterministic "
    "audit findings. PDF extraction, PII redaction, and chunking are real. "
    "Vector retrieval and local LLM analysis will be connected later."
)

st.sidebar.subheader("Synthetic Dataset")
st.sidebar.write(
    "The bundled contract contains synthetic PII, a compliant encryption "
    "clause, a non-compliant notification clause, ambiguous retention "
    "wording, and deliberately missing audit rights."
)

st.title("RAG-Powered Vendor Compliance Auditor")
st.markdown("**Demonstration Version**")
st.warning(
    "Illustrative demonstration only. Findings use synthetic data and are "
    "not legal or compliance advice."
)

uploaded_file = st.file_uploader("Upload Contract PDF", type=["pdf"])

if uploaded_file is not None:
    file_bytes = uploaded_file.getvalue()
    file_key = (uploaded_file.name, len(file_bytes))

    if file_key != st.session_state.uploaded_file_key:
        st.session_state.audit_completed = False
        st.session_state.extracted_document = None
        st.session_state.uploaded_file_key = file_key
        st.session_state.redaction_summary = None
        st.session_state.contract_chunks = []

    st.success(f"Selected file: {uploaded_file.name}")

    if st.button("Extract PDF Text", type="primary"):
        try:
            st.session_state.extracted_document = extract_pdf(
                file_bytes,
                uploaded_file.name,
            )

            # Extraction changed, so discard older downstream results.
            st.session_state.redaction_summary = None
            st.session_state.contract_chunks = []
            st.session_state.audit_completed = False

        except DocumentExtractionError as exc:
            st.session_state.extracted_document = None
            st.session_state.redaction_summary = None
            st.session_state.contract_chunks = []
            st.session_state.audit_completed = False
            st.error(str(exc))

if st.session_state.extracted_document is not None:
    document = st.session_state.extracted_document

    st.subheader("Extraction Preview")
    e1, e2, e3 = st.columns(3)
    e1.metric("Pages Extracted", document.page_count)
    e2.metric("Characters Extracted", f"{document.character_count:,}")
    e3.metric("Source File", document.filename)

    selected_page_number = st.selectbox(
        "Preview extracted page",
        options=[page.page_number for page in document.pages],
        format_func=lambda value: f"Page {value}",
    )
    selected_page = next(
        page
        for page in document.pages
        if page.page_number == selected_page_number
    )
    st.text_area(
        "Extracted text",
        value=selected_page.text or "No text extracted from this page.",
        height=260,
        disabled=True,
    )

st.divider()
st.subheader("Privacy Processing")

if st.button("Redact PII and Create Chunks"):
    try:
        with st.spinner(
            "Detecting selected PII and creating sanitized chunks..."
        ):
            summary = redact_document(document)

            st.session_state.redaction_summary = summary
            st.session_state.contract_chunks = chunk_document(
                summary.sanitized_document,
                document_id="SYN-VSA-002",
            )

    except Exception as exc:
        st.session_state.redaction_summary = None
        st.session_state.contract_chunks = []

        st.error(
            "Privacy processing could not be completed. "
            "Confirm that the Presidio dependencies and "
            "en_core_web_lg spaCy model are available."
        )

    if st.session_state.redaction_summary is not None:
        summary = st.session_state.redaction_summary
        chunks = st.session_state.contract_chunks

        r1, r2, r3 = st.columns(3)
        r1.metric("PII Detections", summary.total_detections)
        r2.metric("Sanitized Pages", summary.sanitized_document.page_count)
        r3.metric("Chunks Created", len(chunks))

        st.caption(
            "Only the sanitized text below may be embedded or stored in ChromaDB."
        )

        preview_page_number = st.selectbox(
            "Preview sanitized page",
            options=[page.page_number for page in summary.sanitized_document.pages],
            format_func=lambda value: f"Page {value}",
            key="sanitized_page_selector",
        )
        sanitized_page = next(
            page
            for page in summary.sanitized_document.pages
            if page.page_number == preview_page_number
        )
        st.text_area(
            "Sanitized text",
            value=sanitized_page.text,
            height=260,
            disabled=True,
        )

        with st.expander("PII detection counts"):
            st.json(summary.counts)

        with st.expander("Sanitized chunk preview"):
            for chunk in chunks:
                st.markdown(
                    f"**{chunk.chunk_id} | Page {chunk.page_number}**"
                )
                st.code(chunk.text)

st.divider()
col1, col2 = st.columns([1, 2])

with col1:
    st.subheader("Sample Policies")
    for policy in SAMPLE_POLICIES:
        with st.expander(policy["title"]):
            st.write(policy["requirement"])

with col2:
    st.subheader("Audit Findings")

    if st.button("Run Mock Audit"):
        st.session_state.audit_completed = True

    if st.session_state.audit_completed:
        df = pd.DataFrame(MOCK_FINDINGS)
        total = len(df)
        compliant = len(df[df["status"] == "COMPLIANT"])
        issues = len(df[df["status"].isin(["NON_COMPLIANT", "MISSING"])])
        review = len(df[df["status"] == "AMBIGUOUS"])

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Policies Checked", total)
        m2.metric("Compliant", compliant)
        m3.metric("Issues", issues)
        m4.metric("Review Needed", review)

        st.subheader("Audit Findings Table")
        st.dataframe(df, use_container_width=True, hide_index=True)

        st.subheader("Finding Summary")
        for finding in MOCK_FINDINGS:
            message = f"{finding['policy']} : {finding['status']}"
            if finding["status"] == "COMPLIANT":
                st.success(message)
            elif finding["status"] == "NON_COMPLIANT":
                st.error(message)
            elif finding["status"] == "MISSING":
                st.warning(message)
            else:
                st.info(message)

        st.subheader("Evidence Details")
        selected_policy = st.selectbox(
            "Select Policy",
            [item["policy"] for item in MOCK_FINDINGS],
        )
        selected_finding = next(
            item for item in MOCK_FINDINGS
            if item["policy"] == selected_policy
        )

        st.write("### Evidence")
        st.code(selected_finding["evidence"])
        st.write("### Explanation")
        st.write(selected_finding["explanation"])
        st.write("### Recommendation")
        st.write(selected_finding["recommendation"])

        page = selected_finding["page"]
        page_display = page if page is not None else "No evidence page"
        st.write(f"**Contract Page:** {page_display}")
        st.caption(
            "The extraction preview is real. Audit findings remain "
            "deterministic until retrieval and local LLM sessions are complete."
        )
