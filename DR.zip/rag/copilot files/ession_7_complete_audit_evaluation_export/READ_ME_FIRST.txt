SESSION 7 - COMPLETE AUDIT, EVALUATION AND EXPORT

Copy the app and tests files into matching project folders. Integrate UI_INTEGRATION.md into app/ui/main.py.

Focused tests:
python -m pytest tests\test_audit_runner.py tests\test_evaluator.py tests\test_report_exporter.py -v

Full regression suite:
python -m pytest -v

Run Streamlit:
python -m streamlit run app\ui\main.py

Workflow: upload, extract, redact/chunk, index, then Run Complete Local Audit.

The runner processes every policy independently. A policy failure is recorded and does not discard other successful findings. Evaluation loads only the expected-findings file matching the indexed document ID, after all model generation is complete. JSON and CSV reports are generated in memory for download.
