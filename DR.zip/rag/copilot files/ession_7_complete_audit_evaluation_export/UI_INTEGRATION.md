# Session 7 UI integration

## Imports

```python
from app.services.audit_runner import run_complete_audit
from app.services.evaluator import evaluate_audit_run, load_expected_findings
from app.services.report_exporter import audit_run_to_csv, audit_run_to_json
```

## Constants

```python
EXPECTED_SUFFIX = "_expected_findings.json"
```

## Session state

Add to `initialize_state()` and clear in `reset_downstream_state()`, after redaction, and after indexing:

```python
"complete_audit_run": None,
"audit_evaluation": None,
```

## Complete-audit UI

Place inside the indexed-chunks section, before the single-policy selector:

```python
st.subheader("Complete Contract Audit")
if st.button("Run Complete Local Audit", type="primary"):
    progress = st.progress(0, text="Preparing complete audit...")

    def update_progress(done: int, total: int, policy_id: str) -> None:
        ratio = done / total if total else 1.0
        progress.progress(
            ratio,
            text=f"Processed {done} of {total} policies | {policy_id}",
        )

    collection = get_collection(CHROMA_PATH)
    audit_run = run_complete_audit(
        collection,
        policy_set,
        document_id=st.session_state.indexed_document_id,
        source_filename=st.session_state.extracted_document.filename,
        prompt_path=AUDIT_PROMPT_PATH,
        top_k=TOP_K,
        progress_callback=update_progress,
    )
    st.session_state.complete_audit_run = audit_run

    expected_path = (
        ROOT
        / "synthetic_data"
        / f"{audit_run.document_id}{EXPECTED_SUFFIX}"
    )
    try:
        expected = load_expected_findings(expected_path)
        st.session_state.audit_evaluation = evaluate_audit_run(
            audit_run, expected
        )
    except (FileNotFoundError, ValueError):
        st.session_state.audit_evaluation = None

    progress.progress(1.0, text="Complete audit finished.")

audit_run = st.session_state.complete_audit_run
if audit_run is not None:
    findings_df = pd.DataFrame([
        {
            "Policy ID": item.policy_id,
            "Status": item.status.value,
            "Severity": item.severity,
            "Confidence": item.confidence,
            "Page": item.contract_page,
            "Chunk ID": item.chunk_id,
            "Human Review": item.requires_human_review,
        }
        for item in audit_run.findings
    ])

    a1, a2, a3 = st.columns(3)
    a1.metric("Policies", audit_run.total_policies)
    a2.metric("Completed", audit_run.successful_findings)
    a3.metric("Failures", audit_run.failed_findings)
    st.dataframe(findings_df, use_container_width=True, hide_index=True)

    if audit_run.failures:
        with st.expander("Policy processing failures"):
            for failure in audit_run.failures:
                st.warning(f"{failure.policy_id}: {failure.error}")

    evaluation = st.session_state.audit_evaluation
    if evaluation is not None:
        st.subheader("Synthetic Ground-Truth Evaluation")
        st.caption(
            "Expected findings are used only after generation and are not sent "
            "to retrieval or the language model."
        )
        e1, e2 = st.columns(2)
        e1.metric("Status Match", f"{evaluation.status_accuracy:.0%}")
        e2.metric("Page Match", f"{evaluation.page_accuracy:.0%}")
        st.dataframe(
            pd.DataFrame([item.model_dump() for item in evaluation.results]),
            use_container_width=True,
            hide_index=True,
        )

    report_json = audit_run_to_json(audit_run, evaluation)
    report_csv = audit_run_to_csv(audit_run)
    d1, d2 = st.columns(2)
    d1.download_button(
        "Download Audit JSON",
        report_json,
        file_name=f"{audit_run.audit_run_id}.json",
        mime="application/json",
    )
    d2.download_button(
        "Download Findings CSV",
        report_csv,
        file_name=f"{audit_run.audit_run_id}.csv",
        mime="text/csv",
    )
```

Keep the existing single-policy workflow below this section. It remains useful for explaining retrieval and debugging individual policies.
