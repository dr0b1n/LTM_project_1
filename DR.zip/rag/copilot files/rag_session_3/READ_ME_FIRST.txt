SESSION 3 INSTALLATION

1. Copy app/models/document.py into your project.
2. Copy app/services/__init__.py and document_extractor.py into app/services/.
3. Back up your current app/ui/main.py, then replace it with the included file.
4. Copy tests/test_document_extractor.py into tests/.
5. Keep your existing requirements.txt. It already includes pypdf, Streamlit, Pydantic and pytest.

PowerShell commands from C:\Users\T9925\Documents\DR\rag:

.\.venv\Scripts\Activate.ps1
python -m pip check
python -m pytest tests/test_document_extractor.py -v
python -m streamlit run app/ui/main.py

Manual verification:
- Upload synthetic_data\synthetic_vendor_contract.pdf
- Click Extract PDF Text
- Confirm 4 pages are reported
- Select pages 1 through 4 and inspect their extracted text
- Click Run Mock Audit and confirm the previous dashboard still works

Important: PDF extraction is real in Session 3. Audit findings are still deterministic mock data.
