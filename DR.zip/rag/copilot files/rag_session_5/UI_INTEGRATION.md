# Session 5 UI integration

## 1. Add imports

Add below the existing service imports in `app/ui/main.py`:

```python
from app.services.embedder import EmbeddingError, embed_texts
from app.services.policy_loader import load_policy_set
from app.services.retriever import retrieve_for_policy
from app.services.vector_store import get_collection, replace_document_chunks
```

## 2. Add session state

Add beside the existing state initialization:

```python
if "retrieval_results" not in st.session_state:
    st.session_state.retrieval_results = {}
if "indexed_chunk_count" not in st.session_state:
    st.session_state.indexed_chunk_count = 0
```

Reset both values whenever a new file is selected, the PDF is re-extracted, or redaction is rerun:

```python
st.session_state.retrieval_results = {}
st.session_state.indexed_chunk_count = 0
```

## 3. Load the five policy JSON file

Near the top, after state initialization:

```python
POLICY_PATH = ROOT / "policies" / "sample_policies.json"
policy_set = load_policy_set(POLICY_PATH)
```

In the Sample Policies section, replace `SAMPLE_POLICIES` with `policy_set.policies` and use attribute access:

```python
for policy in policy_set.policies:
    with st.expander(f"{policy.policy_id}: {policy.title}"):
        st.write(policy.requirement)
        st.caption(f"Severity: {policy.severity} | Version: {policy.policy_version}")
```

You may then remove the `SAMPLE_POLICIES` import. Keep `MOCK_FINDINGS` until Session 6.

## 4. Add indexing and retrieval UI

Place this after the sanitized chunk preview and before the mock audit section:

```python
if st.session_state.contract_chunks:
    st.divider()
    st.subheader("Vector Index and Policy Retrieval")

    if st.button("Index Sanitized Chunks"):
        try:
            with st.spinner("Generating local embeddings and updating ChromaDB..."):
                chunks = st.session_state.contract_chunks
                vectors = embed_texts([chunk.text for chunk in chunks])
                collection = get_collection(ROOT / "data" / "chroma")
                stored = replace_document_chunks(collection, chunks, vectors)
                st.session_state.indexed_chunk_count = stored
                st.session_state.retrieval_results = {}
            st.success(f"Indexed {stored} sanitized chunks.")
        except EmbeddingError as exc:
            st.error(str(exc))
        except Exception as exc:
            print(f"Vector indexing error: {exc}")
            st.error("Vector indexing could not be completed.")

    if st.session_state.indexed_chunk_count:
        st.metric("Indexed Sanitized Chunks", st.session_state.indexed_chunk_count)

        selected_retrieval_policy = st.selectbox(
            "Select a policy retrieval query",
            policy_set.policies,
            format_func=lambda policy: f"{policy.policy_id}: {policy.title}",
            key="retrieval_policy_selector",
        )

        if st.button("Retrieve Top 3 Evidence Chunks"):
            try:
                collection = get_collection(ROOT / "data" / "chroma")
                document_id = st.session_state.contract_chunks[0].document_id
                results = retrieve_for_policy(
                    collection,
                    selected_retrieval_policy,
                    document_id=document_id,
                    top_k=3,
                )
                st.session_state.retrieval_results[
                    selected_retrieval_policy.policy_id
                ] = results
            except EmbeddingError as exc:
                st.error(str(exc))
            except Exception as exc:
                print(f"Retrieval error: {exc}")
                st.error("Evidence retrieval could not be completed.")

        current_results = st.session_state.retrieval_results.get(
            selected_retrieval_policy.policy_id, []
        )
        for rank, evidence in enumerate(current_results, start=1):
            with st.expander(
                f"Result {rank}: Page {evidence.page_number} | {evidence.chunk_id}",
                expanded=(rank == 1),
            ):
                st.write(evidence.text)
                if evidence.distance is not None:
                    st.caption(f"Vector distance: {evidence.distance:.4f} (lower is closer)")
```

## 5. Verification

Use the clean six-page PDF. After redaction and chunking, index the chunks, select each policy, and retrieve its top three results. Expected strongest pages are usually: POL-001 page 2, POL-002 page 3, POL-004 page 4, and POL-005 page 5. For POL-003 audit rights, no strongly relevant operative clause exists, so do not interpret the top result as proof. Missing classification belongs to Session 6.
