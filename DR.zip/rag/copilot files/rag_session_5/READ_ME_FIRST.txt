SESSION 5 - OLLAMA EMBEDDINGS, CHROMADB AND RETRIEVAL

Copy the included app and tests files into the matching project folders. Integrate UI_INTEGRATION.md into app/ui/main.py. Rename the active policy file to policies\sample_policies.json.

PowerShell verification from the project root:

.\.venv\Scripts\Activate.ps1
ollama --version
ollama list
python -c "import ollama; r=ollama.embed(model='granite-embedding:30m', input=['vendor encrypts data at rest']); print(len(r['embeddings']), len(r['embeddings'][0]))"

Expected embedding check: 1 384

Run focused tests which do not require a live Ollama server:
python -m pytest tests\test_policy_loader.py tests\test_embedder.py tests\test_vector_store.py -v

Run the complete regression suite:
python -m pytest -v

Run Streamlit:
python -m streamlit run app\ui\main.py

UI sequence:
1. Upload and extract the clean six-page PDF.
2. Redact PII and create chunks.
3. Index sanitized chunks.
4. Select a policy and retrieve the top three evidence chunks.
5. Verify page metadata and that no original PII is displayed.

Session 5 does not classify compliance. It retrieves evidence only.
