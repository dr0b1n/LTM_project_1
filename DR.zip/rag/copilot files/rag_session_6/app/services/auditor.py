import json
import os
from pathlib import Path
from typing import Any
import ollama
from pydantic import ValidationError
from app.models.finding import AuditFinding, FindingStatus
from app.models.policy import Policy
from app.models.retrieval import RetrievedEvidence
from app.services.embedder import EMBEDDING_MODEL

DEFAULT_INFERENCE_MODEL = os.getenv("OLLAMA_MODEL", "granite4.1:8b")
PROMPT_VERSION = "v1"

class AuditGenerationError(RuntimeError):
    pass

def _evidence_payload(evidence: list[RetrievedEvidence]) -> list[dict[str, Any]]:
    return [{"rank": i, "chunk_id": item.chunk_id, "page": item.page_number, "distance": item.distance, "text": item.text} for i, item in enumerate(evidence, 1)]

def _response_content(response: Any) -> str:
    if isinstance(response, dict):
        return response.get("message", {}).get("content", "")
    message = getattr(response, "message", None)
    return getattr(message, "content", "") if message is not None else ""

def audit_policy(policy: Policy, evidence: list[RetrievedEvidence], prompt_path: str | Path, model: str = DEFAULT_INFERENCE_MODEL) -> AuditFinding:
    prompt = Path(prompt_path).read_text(encoding="utf-8")
    user_payload = {"policy": policy.model_dump(), "retrieved_evidence": _evidence_payload(evidence)}
    try:
        response = ollama.chat(
            model=model,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": json.dumps(user_payload, indent=2)},
            ],
            format=AuditFinding.model_json_schema(),
            options={"temperature": 0},
        )
        content = _response_content(response)
        if not content:
            raise AuditGenerationError("Ollama returned an empty audit response.")
        finding = AuditFinding.model_validate_json(content)
    except AuditGenerationError:
        raise
    except (ValidationError, json.JSONDecodeError) as exc:
        raise AuditGenerationError("The local model returned an invalid structured finding.") from exc
    except Exception as exc:
        raise AuditGenerationError(f"Ollama could not generate a finding with {model}.") from exc

    # Authoritative application fields cannot be changed by the model.
    finding.policy_id = policy.policy_id
    finding.policy_version = policy.policy_version
    finding.policy_requirement = policy.requirement
    finding.severity = policy.severity
    finding.embedding_model = EMBEDDING_MODEL
    finding.inference_model = model
    finding.prompt_version = PROMPT_VERSION

    evidence_by_id = {item.chunk_id: item for item in evidence}
    if finding.status != FindingStatus.MISSING:
        selected = evidence_by_id.get(finding.chunk_id or "")
        if selected is None:
            raise AuditGenerationError("The finding cited a chunk that was not retrieved.")
        finding.retrieved_clause = selected.text
        finding.contract_page = selected.page_number
        finding.retrieval_distance = selected.distance

    return AuditFinding.model_validate(finding.model_dump())
