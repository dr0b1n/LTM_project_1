# Session 6 UI integration

Add imports:

```python
from app.models.finding import FindingStatus
from app.services.auditor import AuditGenerationError, audit_policy
```

Add constants:

```python
AUDIT_PROMPT_PATH = ROOT / "prompts" / "compliance_audit_v1.txt"
```

Add state and reset it whenever a new file is selected, extraction/redaction/indexing changes, or retrieval becomes stale:

```python
if "real_findings" not in st.session_state:
    st.session_state.real_findings = {}
```

After the retrieval results display, add a button that audits the selected policy only when retrieval results exist:

```python
if current_results:
    if st.button("Generate Structured Finding"):
        try:
            with st.spinner("Comparing the policy with retrieved evidence..."):
                finding = audit_policy(
                    selected_retrieval_policy,
                    current_results,
                    AUDIT_PROMPT_PATH,
                )
                st.session_state.real_findings[
                    selected_retrieval_policy.policy_id
                ] = finding
        except AuditGenerationError as exc:
            st.error(str(exc))

current_finding = st.session_state.real_findings.get(
    selected_retrieval_policy.policy_id
)
if current_finding is not None:
    st.subheader("Structured Finding")
    st.write(f"**Status:** {current_finding.status.value}")
    st.write(f"**Severity:** {current_finding.severity}")
    st.write(f"**Confidence:** {current_finding.confidence:.2f}")
    st.write("**Explanation**")
    st.write(current_finding.explanation)
    st.write("**Evidence**")
    st.code(current_finding.retrieved_clause or "No supporting clause found.")
    st.write(
        f"**Page:** {current_finding.contract_page or 'No evidence page'}"
    )
    st.write(
        f"**Chunk:** {current_finding.chunk_id or 'No evidence chunk'}"
    )
    st.write("**Recommendation**")
    st.write(current_finding.recommended_remediation)
    if current_finding.requires_human_review:
        st.warning("Human review required.")
```

Keep the mock audit as a clearly labeled fallback until the real findings have been manually verified for all five policies.
