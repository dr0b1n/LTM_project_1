SESSION 6 - LOCAL STRUCTURED COMPLIANCE FINDINGS

Copy the included files into the matching locations. Replace app/models/finding.py with the new schema. Integrate UI_INTEGRATION.md into app/ui/main.py.

Verify the instruction model exists:
ollama list

If granite4.1:8b is unavailable, set OLLAMA_MODEL to an installed approved local instruction model before starting Streamlit.

Focused tests:
python -m pytest tests\test_finding.py tests\test_auditor.py -v

Full regression suite:
python -m pytest -v

Run UI:
python -m streamlit run app\ui\main.py

Workflow: upload, extract, redact/chunk, index, retrieve, generate structured finding.

Acceptance: valid Pydantic finding, cited chunk must be one of retrieved chunks, authoritative page/text metadata comes from retrieval rather than the model, malformed JSON produces a controlled error, and material findings require human review.
