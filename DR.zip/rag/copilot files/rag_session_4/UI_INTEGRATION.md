# Session 4 UI integration

Add these imports below the existing document extractor imports in `app/ui/main.py`:

```python
from app.services.chunker import chunk_document
from app.services.pii_redactor import redact_document
```

Add these session-state values beside the existing session-state initialization:

```python
if "redaction_summary" not in st.session_state:
    st.session_state.redaction_summary = None
if "contract_chunks" not in st.session_state:
    st.session_state.contract_chunks = []
```

When a newly uploaded file is detected, reset them inside the existing file-key block:

```python
st.session_state.redaction_summary = None
st.session_state.contract_chunks = []
```

After the existing Extraction Preview section, add:

```python
if st.session_state.extracted_document is not None:
    st.divider()
    st.subheader("Privacy Processing")

    if st.button("Redact PII and Create Chunks"):
        with st.spinner("Detecting selected PII and creating sanitized chunks..."):
            summary = redact_document(st.session_state.extracted_document)
            st.session_state.redaction_summary = summary
            st.session_state.contract_chunks = chunk_document(
                summary.sanitized_document,
                document_id="SYN-VSA-002",
            )

if st.session_state.redaction_summary is not None:
    summary = st.session_state.redaction_summary
    chunks = st.session_state.contract_chunks

    r1, r2, r3 = st.columns(3)
    r1.metric("PII Detections", summary.total_detections)
    r2.metric("Sanitized Pages", summary.sanitized_document.page_count)
    r3.metric("Chunks Created", len(chunks))

    st.caption(
        "Only the sanitized text below may be embedded or stored in ChromaDB."
    )

    preview_page_number = st.selectbox(
        "Preview sanitized page",
        options=[page.page_number for page in summary.sanitized_document.pages],
        format_func=lambda value: f"Page {value}",
        key="sanitized_page_selector",
    )
    sanitized_page = next(
        page
        for page in summary.sanitized_document.pages
        if page.page_number == preview_page_number
    )
    st.text_area(
        "Sanitized text",
        value=sanitized_page.text,
        height=260,
        disabled=True,
    )

    with st.expander("PII detection counts"):
        st.json(summary.counts)

    with st.expander("Sanitized chunk preview"):
        for chunk in chunks:
            st.markdown(
                f"**{chunk.chunk_id} | Page {chunk.page_number}**"
            )
            st.code(chunk.text)
```

The first Presidio run may take longer because the spaCy model is loaded and cached. Do not pass `st.session_state.extracted_document` directly to embeddings or ChromaDB in later sessions. Use `st.session_state.contract_chunks`.
