SESSION 4 - PII REDACTION AND CHUNKING

Files to copy into the existing project:
- app/models/chunk.py
- app/services/pii_redactor.py
- app/services/chunker.py
- tests/test_pii_redactor.py
- tests/test_chunker.py

Keep the existing Session 3 files, including app/models/document.py and app/services/document_extractor.py.

PowerShell commands from the project root:

.\.venv\Scripts\Activate.ps1
python -c "import spacy; spacy.load('en_core_web_lg'); print('spaCy model ready')"
python -m pytest tests/test_pii_redactor.py tests/test_chunker.py -v

Expected: 4 tests pass.

Then integrate the supplied Session 4 UI blocks from UI_INTEGRATION.md into app/ui/main.py.

Session 4 acceptance:
- Page 1 shows sanitized placeholders for selected PII.
- Only sanitized text is passed to chunk_document.
- Chunks preserve source, page number and chunk ID.
- Original extracted text remains only in memory for the local preview.
