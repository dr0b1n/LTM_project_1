terraform {
  required_version = ">= 1.0"
}

locals {
  project_name = "synthetic-finops-demo"
}

output "project_name" {
  value = local.project_name
}
