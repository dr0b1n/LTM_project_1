# Session 5: Review-only Terraform proposal artifacts

This package adds allow-listed Jinja templates and a compiler that generates non-destructive Terraform proposal files. The generated `.tf` files contain only `terraform`, `locals`, and `output` blocks. They declare no cloud resources or modules and are never applied by the application.

## Files

- `finops_demo/remediation_compiler.py`
- `generate_artifacts.py`
- `templates/terraform/downsize_proposal.tf.j2`
- `templates/terraform/archive_proposal.tf.j2`
- `tests/test_remediation_compiler.py`

## Run

```powershell
python .\generate_artifacts.py
python -m pytest .\tests -v
python -m ruff check .\app.py .\validate_inputs.py .\analyze_inputs.py .\generate_report.py .\generate_artifacts.py .\finops_demo .\tests
```

Expected output location:

```text
output/terraform/
```

Session 6 will format and validate these files with Terraform and TFLint. Do not run `terraform apply`.
