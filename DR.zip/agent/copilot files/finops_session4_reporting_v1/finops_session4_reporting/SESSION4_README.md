# Session 4: Portfolio Reporting

## Additions

- `finops_demo/reporting.py`: portfolio totals, savings separation, aggregations, prioritization, and serialization.
- `generate_report.py`: writes JSON and CSV reports under `output/reports`.
- `tests/test_reporting.py`: five focused reporting tests.

## Install

Copy the extracted package contents into the project root. These files do not replace the policy engine, dataset, policies, or existing tests.

## Verify

```powershell
python .\generate_report.py
python -m pytest .\tests -v
python -m ruff check .\app.py .\validate_inputs.py .\analyze_inputs.py .\generate_report.py .\finops_demo .\tests
python -m compileall -q .\app.py .\validate_inputs.py .\analyze_inputs.py .\generate_report.py .\finops_demo .\tests
```

If the prior 14 tests remain present, the intended total after this package is 19 tests.

## Reports

```text
output/reports/finops_review_report.json
output/reports/finops_review_report.csv
```

Confirmed savings include only `WASTE_DETECTED`. Potential savings attached to `REVIEW_REQUIRED` are shown separately.
