# Session 7 stabilization package

## Purpose

This package makes local Terraform proposal validation repeatable, records the checksum lifecycle transparently, adds validation-evidence tests, and provides repository safety-review guidance.

## Files

- `validate-terraform.ps1`: formats, initializes, validates, lints, safety-scans, hashes, and records evidence for all five proposal directories.
- `security-review.ps1`: searches source files for potential secrets and unsafe Terraform command text.
- `tests/test_validation_evidence.py`: validates the generated evidence.
- `GITIGNORE_SESSION7.txt`: entries to merge into the existing `.gitignore`; do not replace it blindly.
- `APP_SESSION7_CHANGES.md`: exact dashboard schema updates.

## Run order

```powershell
python .\generate_artifacts.py
.\validate-terraform.ps1
python -m pytest .\tests -v
.\security-review.ps1
python -m ruff check .
python -m pip check
```

Terraform validation checks syntax and internal consistency and does not validate remote services. The script initializes with `-backend=false`, writes JSON and CSV evidence, and never runs plan or apply.

## Generated evidence

```text
output/reports/terraform_validation_results.json
output/reports/terraform_validation_results.csv
```

## Important

Potential secret-pattern matches require human review because safe test strings and forbidden-token definitions can match. Generated `output/` remains excluded from Git.
