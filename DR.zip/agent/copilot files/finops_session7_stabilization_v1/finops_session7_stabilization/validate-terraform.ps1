[CmdletBinding()]
param(
    [string]$TerraformExecutable = "C:\Users\T9925\Tools\Terraform\terraform.exe",
    [string]$TFLintExecutable = "C:\Users\T9925\Tools\TFLint\tflint.exe",
    [string]$TerraformOutputDirectory = ".\output\terraform",
    [string]$ReportOutputDirectory = ".\output\reports",
    [int]$ExpectedArtifactCount = 5
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Invoke-ExternalTool {
    param(
        [Parameter(Mandatory)]
        [string]$Executable,
        [Parameter(Mandatory)]
        [string[]]$Arguments,
        [Parameter(Mandatory)]
        [string]$FailureMessage
    )

    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "$FailureMessage Exit code: $LASTEXITCODE"
    }
}

if (-not (Test-Path -LiteralPath $TerraformExecutable -PathType Leaf)) {
    throw "Terraform executable was not found: $TerraformExecutable"
}
if (-not (Test-Path -LiteralPath $TFLintExecutable -PathType Leaf)) {
    throw "TFLint executable was not found: $TFLintExecutable"
}
if (-not (Test-Path -LiteralPath $TerraformOutputDirectory -PathType Container)) {
    throw "Terraform output directory was not found: $TerraformOutputDirectory"
}

$manifestPath = Join-Path $TerraformOutputDirectory "artifact_manifest.json"
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw "Artifact manifest was not found: $manifestPath"
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.execution_enabled -ne $false) {
    throw "Artifact manifest must state execution_enabled=false."
}
if ($manifest.dry_run -ne $true) {
    throw "Artifact manifest must state dry_run=true."
}

$directories = @(
    Get-ChildItem -LiteralPath $TerraformOutputDirectory -Directory |
        Sort-Object Name
)
if ($directories.Count -ne $ExpectedArtifactCount) {
    throw "Expected $ExpectedArtifactCount artifact directories but found $($directories.Count)."
}

$results = foreach ($directory in $directories) {
    Write-Host "`n=== Validating $($directory.Name) ===" -ForegroundColor Cyan

    $proposalFiles = @(Get-ChildItem -LiteralPath $directory.FullName -Filter *.tf -File)
    if ($proposalFiles.Count -ne 1) {
        throw "Expected one .tf proposal in $($directory.Name), found $($proposalFiles.Count)."
    }

    $proposalPath = $proposalFiles[0].FullName
    $manifestEntry = @($manifest.artifacts | Where-Object resource_id -eq $directory.Name)
    if ($manifestEntry.Count -ne 1) {
        throw "Expected one manifest entry for $($directory.Name)."
    }

    $generationHash = $manifestEntry[0].sha256.ToLowerInvariant()
    $preFormatHash = (
        Get-FileHash -LiteralPath $proposalPath -Algorithm SHA256
    ).Hash.ToLowerInvariant()

    Invoke-ExternalTool -Executable $TerraformExecutable `
        -Arguments @("-chdir=$($directory.FullName)", "fmt") `
        -FailureMessage "Terraform fmt failed for $($directory.Name)."

    $postFormatHash = (
        Get-FileHash -LiteralPath $proposalPath -Algorithm SHA256
    ).Hash.ToLowerInvariant()

    $fmtPassed = $false
    & $TerraformExecutable "-chdir=$($directory.FullName)" fmt -check
    $fmtPassed = $LASTEXITCODE -eq 0

    $initPassed = $false
    & $TerraformExecutable "-chdir=$($directory.FullName)" init -backend=false -input=false
    $initPassed = $LASTEXITCODE -eq 0

    $validatePassed = $false
    $terraformValidateJson = ""
    if ($initPassed) {
        $terraformValidateJson = & $TerraformExecutable `
            "-chdir=$($directory.FullName)" validate -json 2>&1 | Out-String
        $validateExitCode = $LASTEXITCODE
        if ($validateExitCode -eq 0) {
            try {
                $validatePayload = $terraformValidateJson | ConvertFrom-Json
                $validatePassed = $validatePayload.valid -eq $true
            }
            catch {
                $validatePassed = $false
            }
        }
    }

    $tflintPassed = $false
    Push-Location $directory.FullName
    try {
        & $TFLintExecutable
        $tflintPassed = $LASTEXITCODE -eq 0
    }
    finally {
        Pop-Location
    }

    $content = Get-Content -LiteralPath $proposalPath -Raw
    $dryRunPresent = $content -match "dry_run\s*=\s*true"
    $approvalPresent = $content -match "human_approval_required\s*=\s*true"
    $unsafePatterns = @(
        'resource\s+"',
        'module\s+"',
        'provider\s+"',
        'local-exec',
        'remote-exec',
        'terraform\s+apply',
        'terraform\s+destroy'
    )
    $unsafeMatches = @(
        foreach ($pattern in $unsafePatterns) {
            if ($content -match $pattern) {
                $pattern
            }
        }
    )
    $safetyPassed = (
        $dryRunPresent -and
        $approvalPresent -and
        $unsafeMatches.Count -eq 0
    )

    $overallPassed = (
        $fmtPassed -and
        $initPassed -and
        $validatePassed -and
        $tflintPassed -and
        $safetyPassed
    )

    [PSCustomObject]@{
        ResourceDirectory = $directory.Name
        ProposalPath = $proposalPath
        TerraformFmt = $fmtPassed
        TerraformInit = $initPassed
        TerraformValidate = $validatePassed
        TFLint = $tflintPassed
        DryRunPresent = $dryRunPresent
        ApprovalRequiredPresent = $approvalPresent
        UnsafeContentFound = $unsafeMatches.Count -gt 0
        GenerationSha256 = $generationHash
        PreFormatSha256 = $preFormatHash
        PostFormatSha256 = $postFormatHash
        GenerationHashMatchedBeforeFormat = $generationHash -eq $preFormatHash
        FormattingChangedFile = $preFormatHash -ne $postFormatHash
        OverallPassed = $overallPassed
    }
}

New-Item -ItemType Directory -Path $ReportOutputDirectory -Force | Out-Null
$jsonPath = Join-Path $ReportOutputDirectory "terraform_validation_results.json"
$csvPath = Join-Path $ReportOutputDirectory "terraform_validation_results.csv"

$results | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $jsonPath -Encoding utf8
$results | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding utf8

$results | Format-Table ResourceDirectory, TerraformFmt, TerraformInit, `
    TerraformValidate, TFLint, OverallPassed -AutoSize

$failed = @($results | Where-Object OverallPassed -ne $true)
Write-Host "`nJSON evidence: $jsonPath"
Write-Host "CSV evidence: $csvPath"

if ($failed.Count -gt 0) {
    Write-Host "`nSession 7 Terraform validation failed." -ForegroundColor Red
    exit 1
}

Write-Host "`nAll review-only proposals passed validation." -ForegroundColor Green
exit 0
