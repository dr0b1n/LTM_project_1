# Session 7 app.py changes

No new application feature is required. Keep the Session 6 Terraform validation section and update its expected schema so it can display the richer evidence produced by `validate-terraform.ps1`.

## Required path

Ensure this constant exists near the other paths:

```python
TERRAFORM_VALIDATION_PATH = (
    PROJECT_ROOT
    / "output"
    / "reports"
    / "terraform_validation_results.json"
)
```

## Required columns

Use these required columns in the Terraform validation section:

```python
required_validation_columns = {
    "ResourceDirectory",
    "TerraformFmt",
    "TerraformInit",
    "TerraformValidate",
    "TFLint",
    "DryRunPresent",
    "ApprovalRequiredPresent",
    "UnsafeContentFound",
    "PostFormatSha256",
    "OverallPassed",
}
```

## Recommended display names

Add these entries to the validation-frame rename mapping:

```python
"DryRunPresent": "Dry Run Present",
"ApprovalRequiredPresent": "Approval Required",
"UnsafeContentFound": "Unsafe Content Found",
"PostFormatSha256": "Validated SHA-256",
```

Display the following columns:

```python
validation_display_columns = [
    "Resource Directory",
    "Terraform Format",
    "Terraform Init",
    "Terraform Validate",
    "TFLint",
    "Dry Run Present",
    "Approval Required",
    "Unsafe Content Found",
    "Validated SHA-256",
    "Overall Passed",
]
```

The validation section should remain after the review-only Terraform proposal section and before the Safety boundary section. Do not label these results as a Terraform plan or real infrastructure validation. Use "review-only Terraform proposal validation."
