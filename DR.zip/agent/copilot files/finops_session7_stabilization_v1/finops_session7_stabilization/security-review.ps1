[CmdletBinding()]
param(
    [string]$ProjectRoot = "."
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$excludedDirectories = @(
    ".venv",
    ".checkov-venv",
    ".git",
    "output",
    "node_modules",
    "session2-extracted",
    "session3-extracted",
    "session4-extracted",
    "session5-extracted"
)

$files = Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File | Where-Object {
    $fullName = $_.FullName
    -not ($excludedDirectories | Where-Object {
        $fullName -match "[\\/]$([regex]::Escape($_))[\\/]"
    })
}

$patterns = @(
    'AKIA[0-9A-Z]{16}',
    'BEGIN [A-Z ]*PRIVATE KEY',
    '(?i)client_secret\s*=',
    '(?i)access_key\s*=',
    '(?i)secret_key\s*=',
    '(?i)password\s*=',
    '(?i)token\s*='
)

$matches = @(
    $files | Select-String -Pattern $patterns -ErrorAction SilentlyContinue
)

$unsafeTerraform = @(
    Get-ChildItem -LiteralPath $ProjectRoot -Recurse -Filter *.tf -File `
        -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '[\\/]output[\\/]' } |
        Select-String -Pattern 'terraform\s+apply', 'terraform\s+destroy' `
            -ErrorAction SilentlyContinue
)

Write-Host "Files reviewed: $($files.Count)"
Write-Host "Potential secret-pattern matches: $($matches.Count)"
Write-Host "Unsafe source Terraform matches: $($unsafeTerraform.Count)"

if ($matches.Count -gt 0) {
    Write-Warning "Review potential secret-pattern matches; some may be safe test strings."
    $matches | Select-Object Path, LineNumber, Line | Format-Table -Wrap
}
if ($unsafeTerraform.Count -gt 0) {
    Write-Warning "Unsafe Terraform command text was found in source .tf files."
    $unsafeTerraform | Select-Object Path, LineNumber, Line | Format-Table -Wrap
}

$report = [PSCustomObject]@{
    FilesReviewed = $files.Count
    PotentialSecretMatches = $matches.Count
    UnsafeTerraformMatches = $unsafeTerraform.Count
    RequiresManualReview = ($matches.Count + $unsafeTerraform.Count) -gt 0
}

$report | ConvertTo-Json | Write-Host

if ($unsafeTerraform.Count -gt 0) {
    exit 1
}
exit 0
