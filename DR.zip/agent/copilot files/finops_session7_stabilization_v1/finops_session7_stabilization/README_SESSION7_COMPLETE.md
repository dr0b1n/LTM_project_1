# Autonomous Cloud FinOps Remediation Agent

A small, synthetic, non-production demonstration of a deterministic, safety-first FinOps workflow for AWS-style and Azure-style resource telemetry.

## Scope

The application validates local synthetic telemetry, loads versioned YAML policies, protects high-risk or ambiguous resources, calculates illustrative savings, produces structured findings, creates reports, and generates allow-listed review-only Terraform proposal artifacts. It does not connect to live cloud accounts, use cloud credentials, run Terraform apply, or modify infrastructure.

## Implemented workflow

```text
Synthetic telemetry
-> Pydantic validation
-> YAML policy validation
-> Safety gates
-> Deterministic policy evaluation
-> Illustrative savings
-> Findings and portfolio reporting
-> Streamlit review interface
-> JSON and CSV reports
-> Review-only Terraform proposal artifacts
-> Terraform format, validate, TFLint, and evidence
-> Human review
```

## Dataset

The dataset contains 24 records: 13 AWS-style and 11 Azure-style resources. It covers 11 compute instances, 6 storage volumes, 5 snapshots, and 2 public IPs. Scenarios include waste, healthy resources, production protection, legal hold, exemptions, missing ownership, ambiguous environments, insufficient observation windows, and threshold edge cases.

## Policies

- Idle compute: CPU at or below 3 percent for at least 14 days -> DOWNSIZE.
- Unattached storage: unattached for at least 14 days -> ARCHIVE.
- Old unreferenced snapshot: at least 90 days old and unreferenced -> ARCHIVE.
- Unassociated public IP -> REVIEW_REQUIRED.

Safety gates run first for production, critical, legal-hold, exempt, missing-owner, unknown-environment, and conflicting-environment cases.

## Current synthetic results

- 5 WASTE_DETECTED
- 6 PROTECTED
- 6 REVIEW_REQUIRED
- 2 INSUFFICIENT_DATA
- 5 NO_WASTE_DETECTED
- USD 153.50 confirmed illustrative monthly savings
- USD 1,842.00 confirmed illustrative annual savings
- USD 4.00 potential monthly savings pending review

## Setup

```powershell
Set-Location "C:\Users\T9925\Documents\DR\agent"
.\.venv\Scripts\Activate.ps1
.\setup-tools.ps1
python -m pip check
```

## Run the workflow

```powershell
python .\validate_inputs.py
python .\analyze_inputs.py
python .\generate_report.py
python .\generate_artifacts.py
.\validate-terraform.ps1
python -m streamlit run .\app.py
```

## Test and quality checks

```powershell
python -m pytest .\tests -v
python -m ruff check .
python -m compileall -q .\app.py .\finops_demo .\tests
python -m pip check
```

## Important files

```text
app.py
validate_inputs.py
analyze_inputs.py
generate_report.py
generate_artifacts.py
validate-terraform.ps1
security-review.ps1
finops_demo/
synthetic_data/resources.json
policies/finops_rules.yaml
expected_findings/expected_findings.json
templates/terraform/
tests/
```

Generated outputs are written beneath `output/reports` and `output/terraform` and should remain excluded from Git.

## Terraform proposal terminology

The generated `.tf` files are review-only proposal artifacts, not real Terraform plans. They declare no providers, resources, or modules. They contain recommendation metadata, dry-run and approval declarations, and cannot change infrastructure. The validation script checks formatting, syntax, internal consistency, linting, safety declarations, and checksums. Terraform validation does not prove that a real cloud deployment would succeed.

## Safety controls

- Synthetic inputs only
- No live cloud credentials or API calls
- Deterministic policy decisions
- Safety checks before optimization
- Human approval metadata for material recommendations
- No dynamic execution of YAML expressions
- Fixed template allow-list
- Strict template variables
- Safe output paths
- Forbidden-content scanning
- No plan or apply execution
- Illustrative, non-guaranteed savings

## Demonstration flow

1. Show the 24-record dataset and four policies.
2. Run input validation.
3. Show safety-first deterministic findings.
4. Review portfolio savings and prioritized recommendations in Streamlit.
5. Generate JSON/CSV reports.
6. Generate five review-only Terraform proposals.
7. Show validation evidence for formatting, validation, TFLint, and safety checks.
8. Reiterate that no cloud mutation occurs.

## Limitations

- Synthetic telemetry and costs
- No authoritative pricing integration
- No live AWS or Azure connection
- No real Terraform plan
- No automatic remediation
- No production authentication, approvals workflow, scheduler, or database
- Not production-ready

## Future work

Potential future work includes approved live read-only telemetry connectors, authoritative pricing sources, enterprise approval integration, controlled real Terraform modules, and production security controls. These are outside the current demonstration scope.
