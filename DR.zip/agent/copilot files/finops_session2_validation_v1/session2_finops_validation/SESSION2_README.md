# Session 2: Input Validation

This package adds typed loading and validation for the synthetic FinOps telemetry and policy files prepared before Session 2.

## Copy location

Extract the ZIP and copy its contents directly into:

```text
C:\Users\T9925\Documents\DR\agent
```

The package intentionally does not overwrite `app.py`, `README.md`, `requirements.txt`, the dataset, or the policy file.

## Files added

```text
finops_demo/models.py
finops_demo/loaders.py
validate_inputs.py
tests/test_input_validation.py
SESSION2_README.md
```

## Run

```powershell
Set-Location "C:\Users\T9925\Documents\DR\agent"
.\.venv\Scripts\Activate.ps1
python .\validate_inputs.py
python -m pytest .\tests -v
python -m ruff check .\validate_inputs.py .\finops_demo .\tests
python -m compileall -q .\validate_inputs.py .\finops_demo .\tests
```

Expected validation totals:

```text
Validated resources: 24
Validated optimization policies: 4
Validated safety gates: 4
Input validation: PASSED
```

## Scope boundary

This session validates and loads inputs only. It does not evaluate policies, calculate findings, execute the descriptive `when` fields, generate Terraform, call cloud APIs, or replace the Session 1 mock dashboard results.
