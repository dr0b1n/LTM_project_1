# Session 3: Deterministic Policy Engine

## Plan

Session 3 connects the validated inputs from Session 2 to explicit Python safety and policy logic. It applies safety gates first, evaluates the four supported resource policies, calculates illustrative savings, writes a JSON findings report, and compares the calculated results with the prepared ground-truth findings.

## Files added

```text
finops_demo/policy_engine.py
analyze_inputs.py
tests/test_policy_engine.py
SESSION3_README.md
SESSION3_MANIFEST.sha256
```

The package does not replace `app.py`. The dashboard should continue to work, and it can be connected to `analyze_files()` only after the Session 3 regression test passes against the user's complete 24-record dataset.

## Run

Copy these files into the project root, then run:

```powershell
python .\analyze_inputs.py
python -m pytest .\tests -v
python -m ruff check .\app.py .\validate_inputs.py .\analyze_inputs.py .\finops_demo .\tests
python -m compileall -q .\app.py .\validate_inputs.py .\analyze_inputs.py .\finops_demo .\tests
```

The analysis report is written to:

```text
output\reports\findings.json
```

## Safety and scope

- Safety gates execute before optimization policies.
- YAML `when` strings are never executed.
- No cloud APIs are used.
- No Terraform is generated or applied.
- Findings are deterministic and review-only.
- Savings are synthetic and illustrative.
