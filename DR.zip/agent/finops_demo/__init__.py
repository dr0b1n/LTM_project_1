"""Small synthetic FinOps demonstration package."""

__version__ = "0.1.0"
