
"""Streamlit review interface for the synthetic FinOps demonstration."""

from pathlib import Path

import pandas as pd
import streamlit as st

from finops_demo.loaders import InputLoadError, load_policies, load_telemetry
from finops_demo.mock_data import calculate_summary, get_mock_findings

PROJECT_ROOT = Path(__file__).resolve().parent
TELEMETRY_PATH = PROJECT_ROOT / "synthetic_data" / "resources.json"
POLICY_PATH = PROJECT_ROOT / "policies" / "finops_rules.yaml"

@st.cache_data
def load_input_readiness() -> dict[str, str | int | bool]:
    """Validate Session 2 inputs for display in the review interface."""

    try:
        dataset = load_telemetry(TELEMETRY_PATH)
        policies = load_policies(POLICY_PATH)
    except InputLoadError as exc:
        return {
            "valid": False,
            "message": str(exc),
            "resources": 0,
            "policies": 0,
            "safety_gates": 0,
        }

    return {
        "valid": True,
        "message": "Telemetry and policy inputs passed validation.",
        "resources": len(dataset.records),
        "policies": len(policies.rules),
        "safety_gates": len(policies.safety_gates),
    }

st.set_page_config(
    page_title="Cloud FinOps Remediation Agent",
    page_icon="☁️",
    layout="wide",
)

st.title("Autonomous Cloud FinOps Remediation Agent")
st.caption("Synthetic, deterministic, non-production demonstration")

st.info(
    "Session 1 uses deterministic mock findings so the review workflow can "
    "be demonstrated before telemetry validation and policy evaluation are "
    "implemented. No cloud resources are accessed or modified."
)

st.subheader("Input readiness")

input_readiness = load_input_readiness()

if input_readiness["valid"]:
    st.success(str(input_readiness["message"]))

    readiness_columns = st.columns(3)
    readiness_columns[0].metric(
        "Validated telemetry records",
        input_readiness["resources"],
    )
    readiness_columns[1].metric(
        "Optimization policies",
        input_readiness["policies"],
    )
    readiness_columns[2].metric(
        "Safety gates",
        input_readiness["safety_gates"],
    )
else:
    st.error("Session 2 input validation failed.")
    st.code(str(input_readiness["message"]))


all_findings = get_mock_findings()
all_findings_frame = pd.DataFrame(all_findings)

with st.sidebar:
    st.header("Finding filters")

    cloud_options = sorted(all_findings_frame["cloud"].unique().tolist())
    status_options = sorted(all_findings_frame["status"].unique().tolist())
    action_options = sorted(all_findings_frame["recommended_action"].unique().tolist())

    selected_clouds = st.multiselect(
        "Cloud provider",
        options=cloud_options,
        default=cloud_options,
    )
    selected_statuses = st.multiselect(
        "Finding status",
        options=status_options,
        default=status_options,
    )
    selected_actions = st.multiselect(
        "Recommended action",
        options=action_options,
        default=action_options,
    )
    protected_filter = st.selectbox(
        "Protection state",
        options=["All resources", "Protected only", "Not protected"],
    )

filtered_frame = all_findings_frame[
    all_findings_frame["cloud"].isin(selected_clouds)
    & all_findings_frame["status"].isin(selected_statuses)
    & all_findings_frame["recommended_action"].isin(selected_actions)
].copy()

if protected_filter == "Protected only":
    filtered_frame = filtered_frame[filtered_frame["protected"]]
elif protected_filter == "Not protected":
    filtered_frame = filtered_frame[~filtered_frame["protected"]]

filtered_findings = filtered_frame.to_dict(orient="records")
summary = calculate_summary(filtered_findings)

st.subheader("Review summary")

metric_columns = st.columns(5)

metric_columns[0].metric(
    "Resources reviewed",
    summary["total_resources"],
)
metric_columns[1].metric(
    "Waste detected",
    summary["waste_detected"],
)
metric_columns[2].metric(
    "Protected",
    summary["protected_resources"],
)
metric_columns[3].metric(
    "Review required",
    summary["review_required"],
)
metric_columns[4].metric(
    "Monthly savings",
    f"${summary['estimated_monthly_savings']:,.2f}",
    help="Illustrative estimate based only on synthetic mock costs.",
)

st.subheader("Synthetic findings")

if filtered_frame.empty:
    st.warning("No findings match the selected filters.")
else:
    display_frame = filtered_frame.rename(
        columns={
            "resource_id": "Resource ID",
            "cloud": "Cloud",
            "resource_type": "Resource Type",
            "matched_policy": "Matched Policy",
            "status": "Status",
            "recommended_action": "Recommended Action",
            "estimated_monthly_savings": "Monthly Savings",
            "protected": "Protected",
            "reason": "Reason",
        }
    )

    display_columns = [
        "Resource ID",
        "Cloud",
        "Resource Type",
        "Matched Policy",
        "Status",
        "Recommended Action",
        "Monthly Savings",
        "Protected",
        "Reason",
    ]

    st.dataframe(
        display_frame[display_columns],
        use_container_width=True,
        hide_index=True,
        column_config={
            "Monthly Savings": st.column_config.NumberColumn(
                "Monthly Savings",
                help="Illustrative synthetic estimate, not guaranteed savings.",
                format="$%.2f",
            ),
            "Protected": st.column_config.CheckboxColumn(
                "Protected",
                help="Protected resources do not receive optimization actions.",
            ),
        },
    )

    st.caption(
        f"Showing {len(filtered_frame)} of {len(all_findings_frame)} "
        "synthetic findings."
    )

st.subheader("Safety boundary")

st.markdown(
    """
- Production and explicitly exempt resources are represented as protected.
- Missing ownership results in `REVIEW_REQUIRED`.
- Recently observed resources receive `NO_ACTION`.
- All recommendations are review-only.
- Terraform apply and cloud mutation are not implemented.
- Savings shown here are illustrative, not guaranteed.
"""
)

with st.expander("What will replace the mock results?"):
    st.markdown(
        """
Later sessions will replace these mock findings with:

1. Pydantic-validated synthetic telemetry.
2. Version-controlled YAML policies.
3. Deterministic safety and policy evaluation.
4. Transparent savings calculations.
5. Allow-listed, plan-only Terraform artifacts.

The Streamlit interface can remain largely unchanged while its data source is
replaced with the real deterministic workflow.
"""
    )
