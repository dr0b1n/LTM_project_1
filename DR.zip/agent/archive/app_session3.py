"""Streamlit review interface for the synthetic FinOps demonstration."""

from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

from finops_demo.loaders import InputLoadError, load_policies, load_telemetry
from finops_demo.policy_engine import analyze_files

PROJECT_ROOT = Path(__file__).resolve().parent
TELEMETRY_PATH = PROJECT_ROOT / "synthetic_data" / "resources.json"
POLICY_PATH = PROJECT_ROOT / "policies" / "finops_rules.yaml"


@st.cache_data
def load_input_readiness() -> dict[str, str | int | bool]:
    """Validate Session 2 inputs for display in the review interface."""

    try:
        dataset = load_telemetry(TELEMETRY_PATH)
        policies = load_policies(POLICY_PATH)
    except InputLoadError as exc:
        return {
            "valid": False,
            "message": str(exc),
            "resources": 0,
            "policies": 0,
            "safety_gates": 0,
        }

    return {
        "valid": True,
        "message": "Telemetry and policy inputs passed validation.",
        "resources": len(dataset.records),
        "policies": len(policies.rules),
        "safety_gates": len(policies.safety_gates),
    }


@st.cache_data
def load_engine_findings() -> list[dict[str, Any]]:
    """Run the deterministic engine and return dashboard-ready findings."""

    findings = analyze_files(TELEMETRY_PATH, POLICY_PATH)
    return [finding.to_dict() for finding in findings]


def calculate_dashboard_summary(
    findings_frame: pd.DataFrame,
) -> dict[str, int | float]:
    """Calculate summary metrics from the currently filtered findings."""

    if findings_frame.empty:
        return {
            "total_resources": 0,
            "waste_detected": 0,
            "protected_resources": 0,
            "review_required": 0,
            "estimated_monthly_savings": 0.0,
        }

    waste_mask = findings_frame["status"] == "WASTE_DETECTED"

    return {
        "total_resources": len(findings_frame),
        "waste_detected": int(waste_mask.sum()),
        "protected_resources": int(findings_frame["protected_resource"].sum()),
        "review_required": int(
            (findings_frame["status"] == "REVIEW_REQUIRED").sum()
        ),
        "estimated_monthly_savings": round(
            float(
                findings_frame.loc[
                    waste_mask,
                    "estimated_monthly_savings",
                ].sum()
            ),
            2,
        ),
    }


st.set_page_config(
    page_title="Cloud FinOps Remediation Agent",
    page_icon="☁️",
    layout="wide",
)

st.title("Autonomous Cloud FinOps Remediation Agent")
st.caption("Validated synthetic inputs with deterministic policy findings")

st.info(
    "This is a synthetic, deterministic, non-production demonstration. "
    "The application validates local telemetry and policies, applies explicit "
    "Python safety and optimization rules, and produces review-only findings. "
    "No cloud resources are accessed or modified."
)

st.subheader("Input readiness")
input_readiness = load_input_readiness()

if input_readiness["valid"]:
    st.success(str(input_readiness["message"]))
    readiness_columns = st.columns(3)
    readiness_columns[0].metric(
        "Validated telemetry records",
        input_readiness["resources"],
    )
    readiness_columns[1].metric(
        "Optimization policies",
        input_readiness["policies"],
    )
    readiness_columns[2].metric(
        "Safety gates",
        input_readiness["safety_gates"],
    )
else:
    st.error("Input validation failed.")
    st.code(str(input_readiness["message"]))
    st.stop()

try:
    all_findings = load_engine_findings()
except (InputLoadError, KeyError, TypeError, ValueError) as exc:
    st.error("The deterministic policy analysis failed.")
    st.code(str(exc))
    st.stop()

if not all_findings:
    st.warning("The deterministic engine returned no findings.")
    st.stop()

all_findings_frame = pd.DataFrame(all_findings)

required_finding_columns = {
    "resource_id",
    "cloud_provider",
    "resource_type",
    "matched_policy",
    "status",
    "recommended_action",
    "current_monthly_cost",
    "estimated_monthly_savings",
    "estimated_annual_savings",
    "protected_resource",
    "requires_human_approval",
    "artifact_expected",
    "reason",
}
missing_columns = required_finding_columns - set(all_findings_frame.columns)

if missing_columns:
    st.error("The policy engine returned an incomplete findings schema.")
    st.code(", ".join(sorted(missing_columns)))
    st.stop()

st.success(
    "The findings below were calculated from the validated synthetic "
    "telemetry and YAML policies using deterministic Python rules."
)

with st.sidebar:
    st.header("Finding filters")

    cloud_options = sorted(all_findings_frame["cloud_provider"].unique().tolist())
    status_options = sorted(all_findings_frame["status"].unique().tolist())
    action_options = sorted(
        all_findings_frame["recommended_action"].unique().tolist()
    )
    resource_type_options = sorted(
        all_findings_frame["resource_type"].unique().tolist()
    )

    selected_clouds = st.multiselect(
        "Cloud provider",
        options=cloud_options,
        default=cloud_options,
    )
    selected_resource_types = st.multiselect(
        "Resource type",
        options=resource_type_options,
        default=resource_type_options,
    )
    selected_statuses = st.multiselect(
        "Finding status",
        options=status_options,
        default=status_options,
    )
    selected_actions = st.multiselect(
        "Recommended action",
        options=action_options,
        default=action_options,
    )
    protected_filter = st.selectbox(
        "Protection state",
        options=["All resources", "Protected only", "Not protected"],
    )

filtered_frame = all_findings_frame[
    all_findings_frame["cloud_provider"].isin(selected_clouds)
    & all_findings_frame["resource_type"].isin(selected_resource_types)
    & all_findings_frame["status"].isin(selected_statuses)
    & all_findings_frame["recommended_action"].isin(selected_actions)
].copy()

if protected_filter == "Protected only":
    filtered_frame = filtered_frame[filtered_frame["protected_resource"]]
elif protected_filter == "Not protected":
    filtered_frame = filtered_frame[~filtered_frame["protected_resource"]]

summary = calculate_dashboard_summary(filtered_frame)

st.subheader("Review summary")
metric_columns = st.columns(5)
metric_columns[0].metric("Resources reviewed", summary["total_resources"])
metric_columns[1].metric("Waste detected", summary["waste_detected"])
metric_columns[2].metric("Protected", summary["protected_resources"])
metric_columns[3].metric("Review required", summary["review_required"])
metric_columns[4].metric(
    "Monthly savings",
    f"${summary['estimated_monthly_savings']:,.2f}",
    help=(
        "Illustrative savings from WASTE_DETECTED findings only. "
        "Review-required potential savings are excluded."
    ),
)

st.subheader("Deterministic policy findings")

if filtered_frame.empty:
    st.warning("No findings match all the selected filters.")
else:
    display_frame = filtered_frame.rename(
        columns={
            "resource_id": "Resource ID",
            "cloud_provider": "Cloud",
            "resource_type": "Resource Type",
            "matched_policy": "Matched Policy",
            "status": "Status",
            "recommended_action": "Recommended Action",
            "current_monthly_cost": "Current Monthly Cost",
            "estimated_monthly_savings": "Monthly Savings",
            "estimated_annual_savings": "Annual Savings",
            "protected_resource": "Protected",
            "requires_human_approval": "Approval Required",
            "artifact_expected": "Artifact Expected",
            "reason": "Reason",
        }
    )
    display_columns = [
        "Resource ID",
        "Cloud",
        "Resource Type",
        "Matched Policy",
        "Status",
        "Recommended Action",
        "Current Monthly Cost",
        "Monthly Savings",
        "Annual Savings",
        "Protected",
        "Approval Required",
        "Artifact Expected",
        "Reason",
    ]

    st.dataframe(
        display_frame[display_columns],
        width="stretch",
        hide_index=True,
        column_config={
            "Current Monthly Cost": st.column_config.NumberColumn(
                "Current Monthly Cost",
                format="$%.2f",
            ),
            "Monthly Savings": st.column_config.NumberColumn(
                "Monthly Savings",
                help="Illustrative synthetic estimate, not guaranteed savings.",
                format="$%.2f",
            ),
            "Annual Savings": st.column_config.NumberColumn(
                "Annual Savings",
                help="Illustrative monthly savings multiplied by 12.",
                format="$%.2f",
            ),
            "Protected": st.column_config.CheckboxColumn(
                "Protected",
                help=(
                    "Protected resources receive NO_ACTION instead of an "
                    "optimization recommendation."
                ),
            ),
            "Approval Required": st.column_config.CheckboxColumn(
                "Approval Required",
                help="Indicates that human review or approval is required.",
            ),
            "Artifact Expected": st.column_config.CheckboxColumn(
                "Artifact Expected",
                help=(
                    "Indicates whether a future plan-only Terraform artifact "
                    "may be generated."
                ),
            ),
        },
    )
    st.caption(
        f"Showing {len(filtered_frame)} of "
        f"{len(all_findings_frame)} deterministic findings."
    )

st.subheader("Finding status distribution")
status_counts = (
    filtered_frame["status"]
    .value_counts()
    .rename_axis("Status")
    .reset_index(name="Resources")
)

if status_counts.empty:
    st.info("No status distribution is available for the selected filters.")
else:
    st.bar_chart(
        status_counts,
        x="Status",
        y="Resources",
    )

st.subheader("Safety boundary")
st.markdown(
    """
- Safety gates run before optimization policies.
- Production, critical, legal-hold, and exempt resources receive `NO_ACTION`.
- Missing ownership and ambiguous environments result in `REVIEW_REQUIRED`.
- Resources with insufficient observation history do not receive an action.
- Zero calculated savings cannot produce a waste finding.
- Every material recommendation requires human approval.
- YAML safety expressions are descriptive and are never dynamically executed.
- Terraform generation and Terraform apply are not implemented in this session.
- No AWS or Azure API calls are performed.
- All costs and savings are synthetic and illustrative.
"""
)

with st.expander("How the deterministic workflow works"):
    st.markdown(
        """
1. Load synthetic telemetry from `synthetic_data/resources.json`.
2. Validate all records using Pydantic models.
3. Load policies from `policies/finops_rules.yaml`.
4. Apply explicit Python safety gates.
5. Select the policy matching the resource type.
6. Check observation windows and policy thresholds.
7. Calculate illustrative monthly and annual savings.
8. Return a structured and explainable finding.
9. Display the result for human review.

The language model does not choose policies, actions, or savings values.
"""
    )

with st.expander("Current project scope"):
    st.markdown(
        """
### Implemented

- Synthetic AWS-style and Azure-style telemetry
- Pydantic input validation
- YAML policy validation
- Deterministic safety gates
- Compute, storage, snapshot, and public-IP policies
- Transparent savings calculations
- Ground-truth regression testing
- JSON findings report
- Streamlit review interface

### Planned for later sessions

- Allow-listed Jinja2 Terraform templates
- Plan-only Terraform artifact generation
- Terraform formatting and validation
- Additional presentation refinements
- Final documentation and demonstration rehearsal

Automatic remediation and `terraform apply` remain outside the project scope.
"""
    )
