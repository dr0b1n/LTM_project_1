# GENERATED REVIEW-ONLY TERRAFORM PROPOSAL
# Synthetic demonstration. This file declares no cloud resources.
# Human approval is required before any future implementation.

terraform {
  required_version = ">= 1.6.0"
}

locals {
  proposal = {
    finding_id               = "finding-aws-dev-ec2-022"
    resource_id              = "aws-dev-ec2-022"
    cloud_provider           = "AWS"
    resource_type            = "compute_instance"
    matched_policy           = "FINOPS-COMPUTE-001"
    recommended_action       = "DOWNSIZE"
    current_monthly_cost     = 70.0
    estimated_monthly_savings = 25.0
    currency                 = "USD"
    reason                   = "CPU and observation window meet the idle-compute policy."
    dry_run                  = true
    human_approval_required  = true
  }
}

output "review_proposal" {
  description = "Review-only synthetic FinOps downsizing proposal."
  value       = local.proposal
}
