# GENERATED REVIEW-ONLY TERRAFORM PROPOSAL
# Synthetic demonstration. This file declares no cloud resources.
# Human approval is required before any future implementation.

terraform {
  required_version = ">= 1.6.0"
}

locals {
  proposal = {
    finding_id               = "finding-aws-dev-vol-009"
    resource_id              = "aws-dev-vol-009"
    cloud_provider           = "AWS"
    resource_type            = "storage_volume"
    matched_policy           = "FINOPS-STORAGE-001"
    recommended_action       = "ARCHIVE"
    current_monthly_cost     = 24.0
    estimated_monthly_savings = 24.0
    currency                 = "USD"
    reason                   = "Volume is unattached beyond the minimum observation period."
    dry_run                  = true
    human_approval_required  = true
  }
}

output "review_proposal" {
  description = "Review-only synthetic FinOps archive proposal."
  value       = local.proposal
}
