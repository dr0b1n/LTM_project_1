# GENERATED REVIEW-ONLY TERRAFORM PROPOSAL
# Synthetic demonstration. This file declares no cloud resources.
# Human approval is required before any future implementation.

terraform {
  required_version = ">= 1.6.0"
}

locals {
  proposal = {
    finding_id               = "finding-aws-dev-snap-014"
    resource_id              = "aws-dev-snap-014"
    cloud_provider           = "AWS"
    resource_type            = "snapshot"
    matched_policy           = "FINOPS-SNAPSHOT-001"
    recommended_action       = "ARCHIVE"
    current_monthly_cost     = 12.0
    estimated_monthly_savings = 12.0
    currency                 = "USD"
    reason                   = "Snapshot is old and unreferenced."
    dry_run                  = true
    human_approval_required  = true
  }
}

output "review_proposal" {
  description = "Review-only synthetic FinOps archive proposal."
  value       = local.proposal
}
